Quickstart
==========

Here is a quick rundown of ffn's capabilities. For a more complete guide, read
the source, or check out the :doc:`API docs <ffn>`.

.. include:: quickstart.rst
