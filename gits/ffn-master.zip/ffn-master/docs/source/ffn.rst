API
===

:mod:`ffn` Package
------------------

.. automodule:: ffn.__init__
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`core` Module
------------------

.. automodule:: ffn.core
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`data` Module
------------------

.. automodule:: ffn.data
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`utils` Module
-------------------

.. automodule:: ffn.utils
    :members:
    :undoc-members:
    :show-inheritance:

