# Portfolio-Allocation-and-Sharpe-Ratio-of-4-companies
The Sharpe ratio is the average return earned in excess of the risk-free rate per unit of volatility or total risk. We will calculate Sharpe ratio and after portfolio allocation of different percents in 4 companies namely, Amazon, Apple, IBM and CISCO. The data is taken from quandl.
